export * from "./{{pascalCase name}}DataAdapter";
