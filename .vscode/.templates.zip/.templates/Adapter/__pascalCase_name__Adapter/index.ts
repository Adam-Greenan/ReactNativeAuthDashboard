export * from "./{{pascalCase name}}Adapter";
