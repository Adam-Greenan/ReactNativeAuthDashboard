export * from "./{{ pascalCase name }}";
