export * from "./{{ pascalCase name }}Screen";
