export * from "./{{pascalCase name}}Command";
