export interface I{{pascalCase name}}Service {
};