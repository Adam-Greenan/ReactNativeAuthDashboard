import { I{{pascalCase name}}Service } from "./I{{pascalCase name}}Service";

export default {} as I{{pascalCase name}}Service