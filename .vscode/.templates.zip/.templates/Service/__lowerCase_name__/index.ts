import { I{{ pascalCase name }}Service } from "./I{{ pascalCase name }}Service";
export * from "./I{{ pascalCase name }}Service";

import service from "./{{pascalCase name}}Provider";
export const {{lowerCase name}}:I{{ pascalCase name }}Service = service;
